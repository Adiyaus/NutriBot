// ============================================================
// src/services/nutritionix.js
// Fetch data nutrisi akurat dari Nutritionix API
// Database: 300.000+ makanan, data verified dari USDA + brands
//
// Cara dapet API key (GRATIS):
// 1. Buka: https://www.nutritionix.com/business/api
// 2. Klik "Get API Key" → pilih plan "Free"
// 3. Dapet APP_ID dan APP_KEY
// ============================================================

const axios = require('axios');
require('dotenv').config();

// Base URL Nutritionix Natural Language API
// Endpoint /v2/natural/nutrients — terima query teks bebas seperti "1 cup nasi goreng"
const NUTRITIONIX_URL = 'https://trackapi.nutritionix.com/v2/natural/nutrients';

/**
 * Fetch data nutrisi dari Nutritionix berdasarkan deskripsi makanan
 *
 * @param {Array} foods - array of { name, portion } dari Gemini
 * @returns {object} - { food_description, calories, protein_g, carbs_g, fat_g, items }
 */
async function getNutritionData(foods) {
    // Gabungkan semua item jadi satu query natural language
    // Contoh: "200g nasi goreng, 1 telur mata sapi, 1 cup teh manis"
    const query = foods
        .map(f => `${f.portion} ${f.name}`)  // "1 cup fried rice"
        .join(', ');                           // gabungkan dengan koma

    console.log(`[Nutritionix] Query: "${query}"`);

    try {
        const response = await axios.post(
            NUTRITIONIX_URL,
            { query },  // body: natural language query
            {
                headers: {
                    'Content-Type':  'application/json',
                    'x-app-id':      process.env.NUTRITIONIX_APP_ID,   // dari .env
                    'x-app-key':     process.env.NUTRITIONIX_APP_KEY,  // dari .env
                    'x-remote-user-id': '0'  // required by API, '0' untuk development
                },
                timeout: 8000 // 8 detik timeout — jangan biarin user nunggu kelamaan
            }
        );

        const foods_data = response.data.foods; // array hasil dari Nutritionix

        if (!foods_data || foods_data.length === 0) {
            throw new Error('NO_RESULTS'); // makanan tidak ditemukan di database
        }

        // Aggregate: jumlahkan semua item kalau ada lebih dari 1 makanan
        let totalCalories = 0;
        let totalProtein  = 0;
        let totalCarbs    = 0;
        let totalFat      = 0;
        const itemDetails = []; // simpan detail per item buat ditampilkan ke user

        for (const item of foods_data) {
            // Field names dari Nutritionix API response
            const cal  = item.nf_calories         || 0; // kalori (kkal)
            const prot = item.nf_protein           || 0; // protein (gram)
            const carb = item.nf_total_carbohydrate|| 0; // karbo (gram)
            const fat  = item.nf_total_fat         || 0; // lemak (gram)

            totalCalories += cal;
            totalProtein  += prot;
            totalCarbs    += carb;
            totalFat      += fat;

            itemDetails.push({
                name:     item.food_name,
                serving:  `${item.serving_qty} ${item.serving_unit}`, // "1 cup"
                calories: Math.round(cal)
            });
        }

        // Deskripsi gabungan semua item yang terdeteksi
        const description = itemDetails
            .map(i => `${i.name} (${i.serving})`)
            .join(', ');

        return {
            food_description: description,
            calories:  Math.round(totalCalories),
            protein_g: parseFloat(totalProtein.toFixed(1)),
            carbs_g:   parseFloat(totalCarbs.toFixed(1)),
            fat_g:     parseFloat(totalFat.toFixed(1)),
            items:     itemDetails,  // detail per item (opsional, buat display lebih detail)
            source:    'nutritionix' // penanda sumber data
        };

    } catch (err) {
        // Handle berbagai error dari Nutritionix
        if (err.message === 'NO_RESULTS') {
            throw new Error('NO_RESULTS');
        }
        if (err.response?.status === 401) {
            console.error('[Nutritionix] API key tidak valid!');
            throw new Error('AUTH_ERROR');
        }
        if (err.response?.status === 429) {
            throw new Error('RATE_LIMIT');
        }
        if (err.code === 'ECONNABORTED') {
            throw new Error('TIMEOUT');
        }
        console.error('[Nutritionix] Error:', err.response?.data || err.message);
        throw new Error('NUTRITIONIX_ERROR');
    }
}

/**
 * Fallback: kalau Nutritionix gagal, pakai estimasi kasar dari Gemini
 * Ini safety net — harusnya jarang kepake
 *
 * @param {string} description - deskripsi makanan dari Gemini
 * @param {object} geminiEstimate - estimasi kasar (opsional)
 */
function buildFallbackNutrition(description, geminiEstimate = null) {
    return {
        food_description: description || 'Makanan tidak teridentifikasi',
        calories:  geminiEstimate?.calories  || 0,
        protein_g: geminiEstimate?.protein_g || 0,
        carbs_g:   geminiEstimate?.carbs_g   || 0,
        fat_g:     geminiEstimate?.fat_g     || 0,
        items:     [],
        source:    'fallback' // penanda: data ini fallback, bukan dari DB resmi
    };
}

module.exports = { getNutritionData, buildFallbackNutrition };

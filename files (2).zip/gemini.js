// ============================================================
// src/services/gemini.js
// TUGAS BARU: Cuma identifikasi nama makanan dari foto
// Urusan nutrisi diserahin ke Nutritionix (lebih akurat!)
// ============================================================

const { GoogleGenerativeAI } = require('@google/generative-ai');
const axios = require('axios');
require('dotenv').config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

/**
 * Download foto dari Telegram server sebagai Buffer
 * @param {string} fileUrl - URL lengkap foto dari Telegram
 */
async function downloadImage(fileUrl) {
    const response = await axios.get(fileUrl, {
        responseType: 'arraybuffer' // minta response dalam format binary
    });
    return Buffer.from(response.data);
}

/**
 * Identifikasi makanan dari foto — HANYA nama, bukan nutrisi
 * Prompt di-simplify supaya Gemini fokus ke deteksi nama yang akurat
 *
 * @param {Buffer} imageBuffer
 * @param {string} mimeType
 * @returns {object} { is_food, foods: [{name, portion}], confidence, original_description }
 */
async function identifyFoodFromImage(imageBuffer, mimeType = 'image/jpeg') {
    // Prompt lebih sederhana & focused — Gemini lebih akurat kalau tugasnya spesifik
    const prompt = `
Kamu adalah food recognition AI. Lihat gambar ini dan identifikasi semua makanan/minuman yang terlihat.

ATURAN:
- Kalau BUKAN makanan/minuman, balas dengan is_food: false
- Sebutkan nama makanan dalam bahasa Inggris (lebih akurat di database nutrisi)
- Estimasi porsi dalam gram atau satuan umum
- Pisahkan setiap item makanan yang berbeda

Balas HANYA JSON ini (tanpa markdown, tanpa teks lain):
{
  "is_food": true,
  "foods": [
    { "name": "nama makanan dalam bahasa Inggris", "portion": "estimasi porsi, contoh: 1 cup, 200g, 1 medium" },
    { "name": "item makanan kedua kalau ada", "portion": "porsinya" }
  ],
  "confidence": "high/medium/low",
  "original_description": "deskripsi singkat makanan dalam bahasa Indonesia"
}
    `.trim();

    try {
        const base64Image = imageBuffer.toString('base64');

        // Kirim gambar + prompt ke Gemini
        const result = await model.generateContent([
            prompt,
            { inlineData: { mimeType, data: base64Image } }
        ]);

        const rawText = result.response.text();

        // Bersihkan backtick kalau Gemini tetep nambahin
        const cleaned = rawText
            .replace(/```json\n?/g, '')
            .replace(/```\n?/g, '')
            .trim();

        let parsed;
        try {
            parsed = JSON.parse(cleaned);
        } catch {
            console.error('[Gemini] Parse error:', cleaned);
            throw new Error('PARSE_ERROR');
        }

        // Kalau bukan makanan atau list kosong
        if (!parsed.is_food || !Array.isArray(parsed.foods) || parsed.foods.length === 0) {
            return { is_food: false, foods: [], confidence: 'low', original_description: '' };
        }

        return {
            is_food:              true,
            foods:                parsed.foods,                   // array of { name, portion }
            confidence:           parsed.confidence || 'medium',
            original_description: parsed.original_description || ''
        };

    } catch (err) {
        if (err.message?.includes('RATE_LIMIT') || err.status === 429) throw new Error('RATE_LIMIT');
        if (err.message?.includes('SAFETY'))                            throw new Error('SAFETY_BLOCK');
        if (err.message === 'PARSE_ERROR')                              throw new Error('PARSE_ERROR');
        console.error('[Gemini] Unexpected error:', err.message);
        throw new Error('GEMINI_ERROR');
    }
}

module.exports = { identifyFoodFromImage, downloadImage };

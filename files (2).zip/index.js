// ============================================================
// src/index.js
// Entry point — inisialisasi Telegraf bot & register semua handler
// Jalankan: node src/index.js
// ============================================================

require('dotenv').config();

const { Telegraf } = require('telegraf'); // framework Telegram bot terbaik untuk Node.js

const {
    handleStart,
    handleHelp,
    handleStatus,
    handleLaporan,
    handleProfil,
    handleText,
    handleCallbackQuery,
    handlePhoto
} = require('./handlers/messageHandler');

// ─── INISIALISASI BOT ─────────────────────────────────────────
// Cukup token — tidak butuh browser, tidak butuh QR code!
const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);

// ─── REGISTER COMMAND HANDLERS ───────────────────────────────
// Telegraf otomatis parse /command dari pesan user

bot.start(handleStart);           // /start (command default Telegram)
bot.command('mulai', handleStart); // /mulai — alias untuk /start
bot.command('help', handleHelp);
bot.command('status', handleStatus);
bot.command('laporan', handleLaporan);
bot.command('profil', handleProfil);

// ─── REGISTER MESSAGE HANDLERS ───────────────────────────────

bot.on('photo', handlePhoto);             // user kirim foto/gambar
bot.on('callback_query', handleCallbackQuery); // user klik inline keyboard button
bot.on('text', handleText);               // semua pesan teks biasa (bukan command)

// ─── ERROR HANDLING GLOBAL ───────────────────────────────────
// Tangkap semua error yang lolos dari handler individual
bot.catch((err, ctx) => {
    console.error(`[Bot] Error untuk update ${ctx.updateType}:`, err.message);
    ctx.reply(`😵 Waduh ada error nih. Coba lagi ya! Kalau masih error, tunggu beberapa saat.`)
        .catch(() => {}); // ignore kalau reply-nya juga gagal
});

// ─── START BOT ───────────────────────────────────────────────
bot.launch()
    .then(() => {
        console.log(`\n✅ ${process.env.BOT_NAME || 'NutriBot'} aktif!`);
        console.log(`🤖 Mode: Long Polling`);
        console.log(`📊 Database: Supabase`);
        console.log(`🔍 Vision: Gemini 1.5 Flash`);
        console.log(`⏰ Started: ${new Date().toLocaleString('id-ID')}`);
        console.log(`\n💬 Cari bot lo di Telegram dan ketik /start\n`);
    })
    .catch(err => {
        console.error('❌ Gagal start bot:', err.message);
        console.log('💡 Cek TELEGRAM_BOT_TOKEN di file .env lo!');
        process.exit(1);
    });

// ─── GRACEFUL SHUTDOWN ────────────────────────────────────────
// Stop bot dengan bersih saat CTRL+C
process.once('SIGINT',  () => { console.log('\n🛑 Stopping bot...'); bot.stop('SIGINT');  });
process.once('SIGTERM', () => { console.log('\n🛑 Stopping bot...'); bot.stop('SIGTERM'); });

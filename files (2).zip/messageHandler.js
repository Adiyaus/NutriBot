// ============================================================
// src/handlers/messageHandler.js
// State machine lengkap — versi HYBRID (Gemini + Nutritionix)
// ============================================================

const db          = require('../services/database');
const gemini      = require('../services/gemini');
const nutritionix = require('../services/nutritionix');
const calc        = require('../utils/calculator');

// Helper: kirim pesan dengan Markdown formatting
async function reply(ctx, text, extra = {}) {
    return ctx.reply(text, { parse_mode: 'Markdown', ...extra });
}

// ─── COMMAND HANDLERS ────────────────────────────────────────

async function handleStart(ctx) {
    const tgId   = ctx.from.id;
    const tgName = ctx.from.first_name || 'bestie';

    await db.upsertUser(tgId, {
        username: ctx.from.username || null,
        registration_step: 'ask_name',
        is_registered: false
    });

    await reply(ctx,
        `Heyy ${tgName}! 👋 Welcome to *NutriBot!*\n\n` +
        `Gua bakal bantu lo track kalori & nutrisi harian pakai AI. ✨\n\n` +
        `First things first — *nama panggilan lo siapa?*`
    );
}

async function handleHelp(ctx) {
    await reply(ctx,
        `🤖 *NutriBot — Command List:*\n\n` +
        `/mulai — daftar atau setup ulang profil\n` +
        `/status — cek sisa kalori hari ini\n` +
        `/laporan — progress 7 hari terakhir\n` +
        `/profil — lihat data profil lo\n` +
        `/help — tampilkan menu ini\n\n` +
        `📸 *Kirim foto makanan* → auto analisis nutrisi!\n\n` +
        `_Data nutrisi powered by Nutritionix Database_ 🥗`
    );
}

async function handleStatus(ctx) {
    const tgId = ctx.from.id;
    const user = await db.getUser(tgId);

    if (!user?.is_registered) {
        await reply(ctx, `Lo belum daftar dulu nih! 😅\nKetik /mulai buat start registrasi ya!`);
        return;
    }

    const summary = await db.getDailySummary(tgId);
    await reply(ctx, buildStatusMessage(summary, user.daily_calorie_goal));
}

async function handleLaporan(ctx) {
    const tgId = ctx.from.id;
    const user = await db.getUser(tgId);

    if (!user?.is_registered) {
        await reply(ctx, `Lo belum daftar nih! Ketik /mulai dulu ya.`);
        return;
    }

    const logs = await db.getWeeklyLogs(tgId);

    if (!logs || logs.length === 0) {
        await reply(ctx, `📭 Belum ada data minggu ini. Yuk mulai log makanan lo! 💪`);
        return;
    }

    const totalCal   = logs.reduce((sum, l) => sum + Number(l.calories), 0);
    const daysLogged = [...new Set(logs.map(l => l.log_date))].length;
    const avgCal     = Math.round(totalCal / daysLogged);
    const diff       = avgCal - user.daily_calorie_goal;

    await reply(ctx,
        `📈 *Laporan Mingguan Lo:*\n\n` +
        `📅 Hari yang ke-log: *${daysLogged}/7 hari*\n` +
        `🔥 Total kalori: *${Math.round(totalCal)} kkal*\n` +
        `📊 Rata-rata/hari: *${avgCal} kkal*\n` +
        `🎯 Target/hari: *${Math.round(user.daily_calorie_goal)} kkal*\n\n` +
        `${diff > 0
            ? `⚠️ Rata-rata lo *over ${Math.round(diff)} kkal/hari*`
            : `✅ Rata-rata lo *under ${Math.abs(Math.round(diff))} kkal/hari* — good job!`
        }\n\n_Keep it up! Consistency is key 🔑_`
    );
}

async function handleProfil(ctx) {
    const tgId = ctx.from.id;
    const user = await db.getUser(tgId);

    if (!user?.is_registered) {
        await reply(ctx, `Lo belum daftar nih! Ketik /mulai dulu ya.`);
        return;
    }

    await reply(ctx,
        `👤 *Profil Lo:*\n\n` +
        `Nama: *${user.name || '-'}*\n` +
        `Umur: *${user.age} tahun*\n` +
        `Gender: *${user.gender}*\n` +
        `Tinggi: *${user.height_cm} cm*\n` +
        `Berat: *${user.weight_kg} kg*\n` +
        `BMR: *${Math.round(user.bmr)} kkal/hari*\n` +
        `TDEE: *${Math.round(user.tdee)} kkal/hari*\n` +
        `Target: *${Math.round(user.daily_calorie_goal)} kkal/hari*\n\n` +
        `_Mau update? Ketik /mulai lagi_`
    );
}

// ─── TEXT HANDLER (State Machine) ────────────────────────────

async function handleText(ctx) {
    const tgId = ctx.from.id;
    const body = ctx.message.text?.trim() || '';
    const user = await db.getUser(tgId);

    if (!user) {
        await reply(ctx,
            `Heyy! 👋 Gua *NutriBot*, nutrition tracker lo!\n\n` +
            `Ketik /mulai buat daftar dan mulai track kalori lo. 🚀`
        );
        return;
    }

    if (user.is_registered && user.registration_step === 'complete') {
        await reply(ctx,
            `Hai ${user.name}! 👋\n\n` +
            `Kirim *foto makanan* buat log nutrisi, atau ketik /help buat list command! 😊`
        );
        return;
    }

    await processRegistrationStep(ctx, tgId, user, body);
}

// ─── REGISTRATION FLOW ────────────────────────────────────────

async function processRegistrationStep(ctx, tgId, user, body) {
    const step = user?.registration_step || 'idle';

    switch (step) {

        case 'ask_name': {
            if (body.length < 2 || body.length > 50) {
                await reply(ctx, `Nama harus 2-50 karakter ya. Coba lagi! 😊`);
                return;
            }
            await db.upsertUser(tgId, { name: body, registration_step: 'ask_age' });
            await reply(ctx,
                `Nice, *${body}*! 😄\n\n` +
                `Sekarang, *umur lo berapa?*\n_(ketik angkanya aja, contoh: 25)_`
            );
            break;
        }

        case 'ask_age': {
            const age = parseInt(body);
            if (isNaN(age) || age < 10 || age > 120) {
                await reply(ctx, `Umur harus angka antara 10-120 ya. Coba lagi!`);
                return;
            }
            await db.upsertUser(tgId, { age, registration_step: 'ask_gender' });
            await ctx.reply(`Got it! *Gender lo?*`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[
                        { text: '👨 Pria',   callback_data: 'gender_pria' },
                        { text: '👩 Wanita', callback_data: 'gender_wanita' }
                    ]]
                }
            });
            break;
        }

        case 'ask_height': {
            const height = parseFloat(body);
            if (isNaN(height) || height < 100 || height > 250) {
                await reply(ctx, `Tinggi badan harus antara 100-250 cm. Coba lagi!`);
                return;
            }
            await db.upsertUser(tgId, { height_cm: height, registration_step: 'ask_weight' });
            await reply(ctx, `Oke! *Berat badan lo sekarang berapa kg?*\n_(contoh: 75)_`);
            break;
        }

        case 'ask_weight': {
            const weight = parseFloat(body);
            if (isNaN(weight) || weight < 20 || weight > 500) {
                await reply(ctx, `Berat badan harus antara 20-500 kg. Coba lagi!`);
                return;
            }
            await db.upsertUser(tgId, { weight_kg: weight, registration_step: 'ask_activity' });
            await ctx.reply(`Almost done! 🎯 *Level aktivitas fisik lo?*`, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🛋️ Santai banget',              callback_data: 'activity_sedentary'   }],
                        [{ text: '🚶 Gerak dikit (1-3x/minggu)',   callback_data: 'activity_light'       }],
                        [{ text: '🏃 Lumayan aktif (3-5x/minggu)', callback_data: 'activity_moderate'    }],
                        [{ text: '💪 Aktif banget (6-7x/minggu)',  callback_data: 'activity_active'      }],
                        [{ text: '🏋️ Super aktif / Atlet',        callback_data: 'activity_very_active' }]
                    ]
                }
            });
            break;
        }

        default:
            await db.updateRegistrationStep(tgId, 'idle');
            await reply(ctx, `Hmm ada yang error nih. Ketik /mulai lagi ya!`);
    }
}

// ─── CALLBACK QUERY HANDLER ───────────────────────────────────

async function handleCallbackQuery(ctx) {
    const tgId = ctx.from.id;
    const data = ctx.callbackQuery.data;

    await ctx.answerCbQuery(); // wajib: hilangkan loading spinner

    // ── Pilihan Gender ──────────────────────────────────────
    if (data.startsWith('gender_')) {
        const gender = data.replace('gender_', '');
        await db.upsertUser(tgId, { gender, registration_step: 'ask_height' });
        await ctx.editMessageText(
            `Gender: *${gender === 'pria' ? '👨 Pria' : '👩 Wanita'}* ✅`,
            { parse_mode: 'Markdown' }
        );
        await reply(ctx, `*Tinggi badan lo berapa cm?*\n_(contoh: 170)_`);
        return;
    }

    // ── Pilihan Aktivitas ───────────────────────────────────
    if (data.startsWith('activity_')) {
        const activityLevel = data.replace('activity_', '');
        const user = await db.getUser(tgId);

        const bmr       = calc.calculateBMR(user.weight_kg, user.height_cm, user.age, user.gender);
        const tdee      = calc.calculateTDEE(bmr, activityLevel);
        const dailyGoal = calc.calculateDailyGoal(tdee);

        await db.upsertUser(tgId, {
            activity_level:      activityLevel,
            bmr, tdee,
            daily_calorie_goal:  dailyGoal,
            is_registered:       true,
            registration_step:   'complete'
        });

        await ctx.editMessageText(
            `Aktivitas: *${calc.ACTIVITY_LABELS[activityLevel]}* ✅`,
            { parse_mode: 'Markdown' }
        );

        await reply(ctx,
            `Yeaay! Registrasi *done*, ${user.name}! 🎉\n\n` +
            calc.formatCalorieReport(bmr, tdee, dailyGoal, activityLevel) +
            `\n\n💡 *Cara pakainya:*\n` +
            `• Kirim *foto makanan* → gua analisis nutrisinya\n` +
            `• /status → cek sisa kalori hari ini\n` +
            `• /laporan → progress minggu ini\n\n` +
            `_Data nutrisi dari Nutritionix Database — akurat & verified! 🥗_`
        );
    }
}

// ─── PHOTO HANDLER (HYBRID: Gemini + Nutritionix) ────────────

async function handlePhoto(ctx) {
    const tgId = ctx.from.id;
    const user = await db.getUser(tgId);

    if (!user?.is_registered) {
        await reply(ctx, `Lo belum daftar nih! 😅 Ketik /mulai dulu ya.`);
        return;
    }

    // Kirim loading message dulu
    const loadingMsg = await reply(ctx,
        `Sebentar ya... 🔍\n` +
        `_Step 1/2: Gemini lagi identifikasi makanannya..._`
    );

    try {
        // ── STEP 1: Gemini Vision → identifikasi nama makanan ──
        const photos    = ctx.message.photo;
        const bestPhoto = photos[photos.length - 1]; // resolusi tertinggi

        const fileInfo = await ctx.telegram.getFile(bestPhoto.file_id);
        const fileUrl  = `https://api.telegram.org/file/bot${process.env.TELEGRAM_BOT_TOKEN}/${fileInfo.file_path}`;

        const imageBuffer  = await gemini.downloadImage(fileUrl);
        const foodIdentity = await gemini.identifyFoodFromImage(imageBuffer, 'image/jpeg');

        // Kalau bukan makanan
        if (!foodIdentity.is_food) {
            await ctx.telegram.editMessageText(
                ctx.chat.id, loadingMsg.message_id, null,
                `Hmm, kayaknya itu bukan foto makanan deh... 🤔\n` +
                `Coba kirim foto yang ada makanannya ya!\n\n` +
                `_Tips: pastiin pencahayaan cukup & makanan keliatan jelas_ 📸`
            );
            return;
        }

        // Update loading message ke step 2
        await ctx.telegram.editMessageText(
            ctx.chat.id, loadingMsg.message_id, null,
            `Makanan ketemu! 🎯 *${foodIdentity.original_description}*\n\n` +
            `_Step 2/2: Lagi cari data nutrisi di database..._`,
            { parse_mode: 'Markdown' }
        );

        // ── STEP 2: Nutritionix → fetch data nutrisi akurat ────
        let nutritionData;
        let dataSource = '📊 _Data dari Nutritionix Database_'; // label sumber data

        try {
            nutritionData = await nutritionix.getNutritionData(foodIdentity.foods);
        } catch (nutritionErr) {
            // Kalau Nutritionix gagal, log warning dan pakai fallback
            console.warn(`[PhotoHandler] Nutritionix failed: ${nutritionErr.message}, using fallback`);
            nutritionData = nutritionix.buildFallbackNutrition(
                foodIdentity.original_description
            );
            dataSource = '⚠️ _Data estimasi (Nutritionix unavailable)_';
        }

        // Simpan ke food_logs
        await db.insertFoodLog(tgId, {
            food_description: nutritionData.food_description,
            calories:         nutritionData.calories,
            protein_g:        nutritionData.protein_g,
            carbs_g:          nutritionData.carbs_g,
            fat_g:            nutritionData.fat_g,
            gemini_raw:       JSON.stringify(foodIdentity.foods) // simpan identifikasi Gemini
        });

        // Ambil total kalori hari ini
        const summary   = await db.getDailySummary(tgId);
        const remaining = user.daily_calorie_goal - (summary.total_calories || 0);

        // Bangun pesan hasil
        const statusEmoji   = remaining > 0 ? '✅' : '🚨';
        const remainingText = remaining > 0
            ? `Sisa: *${Math.round(remaining)} kkal* buat hari ini`
            : `⚠️ Lo udah *over ${Math.abs(Math.round(remaining))} kkal* dari target!`;

        // Kalau ada lebih dari 1 item, tampilkan breakdown per item
        const itemBreakdown = nutritionData.items?.length > 1
            ? `\n📋 *Breakdown:*\n` +
              nutritionData.items.map(i => `• ${i.name}: ${i.calories} kkal`).join('\n') + '\n'
            : '';

        const resultText =
            `${statusEmoji} *Hasil Analisis Makanan:*\n\n` +
            `🍽️ *${nutritionData.food_description}*\n\n` +
            `🔥 Kalori: *${Math.round(nutritionData.calories)} kkal*\n` +
            `💪 Protein: *${nutritionData.protein_g}g*\n` +
            `🍚 Karbo: *${nutritionData.carbs_g}g*\n` +
            `🥑 Lemak: *${nutritionData.fat_g}g*\n` +
            `${itemBreakdown}\n` +
            `${dataSource}\n\n` +
            `━━━━━━━━━━━━━━\n` +
            `📊 *Progress Hari Ini (${Math.round(user.daily_calorie_goal)} kkal target):*\n` +
            `${remainingText}\n\n` +
            `_Mau log lagi? Kirim foto berikutnya! 📸_`;

        await ctx.telegram.editMessageText(
            ctx.chat.id, loadingMsg.message_id, null,
            resultText,
            { parse_mode: 'Markdown' }
        );

    } catch (err) {
        console.error(`[PhotoHandler] Error for ${tgId}:`, err.message);

        const errorMessages = {
            'RATE_LIMIT':   `⏳ API-nya lagi overload. Coba lagi dalam beberapa detik ya!`,
            'SAFETY_BLOCK': `🚫 Gambar gak bisa diproses. Kirim foto makanan biasa aja ya!`,
            'GEMINI_ERROR': `😵 Ada error di identifikasi gambar. Coba kirim ulang!`,
        };

        const errMsg = errorMessages[err.message] || `❌ Something went wrong. Coba lagi ya!`;
        await ctx.telegram.editMessageText(ctx.chat.id, loadingMsg.message_id, null, errMsg)
            .catch(() => reply(ctx, errMsg)); // fallback kalau edit gagal
    }
}

// ─── HELPER ───────────────────────────────────────────────────

function buildProgressBar(pct) {
    const filled = Math.round(Math.min(pct, 100) / 10);
    return '█'.repeat(filled) + '░'.repeat(10 - filled);
}

function buildStatusMessage(summary, dailyGoal) {
    const consumed   = Math.round(summary.total_calories || 0);
    const remaining  = Math.round(dailyGoal - consumed);
    const percentage = Math.min(100, Math.round((consumed / dailyGoal) * 100));

    return (
        `📊 *Status Kalori Hari Ini:*\n\n` +
        `${buildProgressBar(percentage)} ${percentage}%\n\n` +
        `🔥 Terpakai: *${consumed} / ${Math.round(dailyGoal)} kkal*\n` +
        `📉 Sisa: *${remaining > 0 ? remaining : 0} kkal*\n\n` +
        `💪 Protein: ${(summary.total_protein || 0).toFixed(1)}g\n` +
        `🍚 Karbo: ${(summary.total_carbs || 0).toFixed(1)}g\n` +
        `🥑 Lemak: ${(summary.total_fat || 0).toFixed(1)}g\n\n` +
        `🍽️ Udah makan ${summary.meal_count || 0}x hari ini\n\n` +
        `${remaining < 0 ? '⚠️ _Lo over budget kalori hari ini!_' : '✅ _Keep going, lo on track!_'}`
    );
}

module.exports = {
    handleStart, handleHelp, handleStatus,
    handleLaporan, handleProfil, handleText,
    handleCallbackQuery, handlePhoto
};

// ============================================================
// src/services/database.js
// Semua interaksi dengan Supabase — pakai telegram_id sebagai key
// ============================================================

const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
);

// ─── USER QUERIES ─────────────────────────────────────────────

/**
 * Ambil data user berdasarkan Telegram ID
 * @param {number} telegramId - ID numerik user dari Telegram
 */
async function getUser(telegramId) {
    const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('telegram_id', telegramId)
        .single();

    // PGRST116 = row not found, bukan error sebenarnya
    if (error && error.code !== 'PGRST116') {
        console.error('[DB] getUser error:', error.message);
    }
    return data; // null kalau user belum ada
}

/**
 * Buat atau update data user (upsert)
 * @param {number} telegramId
 * @param {object} updates - field yang mau diupdate
 */
async function upsertUser(telegramId, updates) {
    const { data, error } = await supabase
        .from('users')
        .upsert(
            { telegram_id: telegramId, ...updates, updated_at: new Date().toISOString() },
            { onConflict: 'telegram_id' } // update kalau sudah ada
        )
        .select()
        .single();

    if (error) {
        console.error('[DB] upsertUser error:', error.message);
        throw new Error('Gagal nyimpen data user');
    }
    return data;
}

/**
 * Update step registrasi (state machine)
 */
async function updateRegistrationStep(telegramId, step) {
    const { error } = await supabase
        .from('users')
        .update({ registration_step: step, updated_at: new Date().toISOString() })
        .eq('telegram_id', telegramId);

    if (error) console.error('[DB] updateStep error:', error.message);
}

// ─── FOOD LOG QUERIES ─────────────────────────────────────────

/**
 * Simpan log makanan baru
 */
async function insertFoodLog(telegramId, nutritionData) {
    const { data, error } = await supabase
        .from('food_logs')
        .insert({
            telegram_id: telegramId,
            log_date: new Date().toISOString().split('T')[0], // YYYY-MM-DD
            ...nutritionData,
            logged_at: new Date().toISOString()
        })
        .select()
        .single();

    if (error) {
        console.error('[DB] insertFoodLog error:', error.message);
        throw new Error('Gagal nyimpen food log');
    }
    return data;
}

/**
 * Ambil total nutrisi hari ini
 */
async function getDailySummary(telegramId) {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
        .from('daily_summary')
        .select('*')
        .eq('telegram_id', telegramId)
        .eq('log_date', today)
        .single();

    if (error && error.code !== 'PGRST116') {
        console.error('[DB] getDailySummary error:', error.message);
    }

    return data || {
        total_calories: 0, total_protein: 0,
        total_carbs: 0, total_fat: 0, meal_count: 0
    };
}

/**
 * Ambil log 7 hari terakhir
 */
async function getWeeklyLogs(telegramId) {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const { data, error } = await supabase
        .from('food_logs')
        .select('log_date, calories, protein_g, carbs_g, fat_g')
        .eq('telegram_id', telegramId)
        .gte('log_date', sevenDaysAgo.toISOString().split('T')[0])
        .order('log_date', { ascending: true });

    if (error) {
        console.error('[DB] getWeeklyLogs error:', error.message);
        return [];
    }
    return data;
}

module.exports = {
    getUser,
    upsertUser,
    updateRegistrationStep,
    insertFoodLog,
    getDailySummary,
    getWeeklyLogs
};
